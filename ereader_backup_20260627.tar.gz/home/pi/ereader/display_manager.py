"""
display_manager.py — All EPD drawing logic.

Hardware: Waveshare 7.5" V2  (800 × 480, SPI)
Driver:   waveshare_epd/epd7in5_V2.py  (standard Waveshare library)

Pin wiring (BCM numbering):
  EPD  →  Pi Zero
  VCC  →  3.3 V  (Pin 1)
  GND  →  GND    (Pin 6)
  DIN  →  GPIO10 (MOSI, Pin 19)
  CLK  →  GPIO11 (SCLK, Pin 23)
  CS   →  GPIO8  (CE0,  Pin 24)
  DC   →  GPIO25 (Pin 22)
  RST  →  GPIO17 (Pin 11)
  BUSY →  GPIO24 (Pin 18)
"""

import os
import textwrap
import logging
from datetime import datetime
from PIL import Image, ImageDraw, ImageFont

log = logging.getLogger('display')

EPD_WIDTH  = 800
EPD_HEIGHT = 480

# Font paths available on Raspbian Lite
FONT_DIR   = "/usr/share/fonts/truetype/dejavu"
FONT_REGULAR = os.path.join(FONT_DIR, "DejaVuSans.ttf")
FONT_BOLD    = os.path.join(FONT_DIR, "DejaVuSans-Bold.ttf")
FONT_MONO    = os.path.join(FONT_DIR, "DejaVuSansMono.ttf")


def _font(path, size):
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()


class DisplayManager:
    def __init__(self, config):
        self.config = config
        self.epd = None
        self._init_epd()

    # ------------------------------------------------------------------  Hardware
    def _init_epd(self):
        try:
            from waveshare_epd import epd7in5_V2
            self.epd = epd7in5_V2.EPD()
            log.info("EPD driver loaded OK")
        except ImportError:
            log.warning("waveshare_epd not found — running in HEADLESS/stub mode")
            self.epd = _StubEPD()

    def init(self):
        """Explicit init — only needed for the boot screen or manual calls."""
        log.info("Initialising EPD...")
        self.epd.init()

    def clear(self):
        """Clear the display and sleep the driver."""
        log.info("Clearing EPD...")
        self.epd.init()
        self.epd.Clear()
        self.epd.sleep()
        log.info("EPD cleared and sleeping")

    def sleep(self):
        log.info("EPD sleeping")
        self.epd.sleep()

    def _display(self, image: Image.Image):
        """
        Push a PIL image to the display, then immediately sleep the controller.

        E-paper holds its image electrostatically — no power is needed to
        maintain the pixels. Leaving the driver IC active after a refresh
        serves no purpose and can contribute to ghosting and long-term
        burn-in. The sequence must therefore always be:
            init() → display() → sleep()
        init() is called here rather than once at startup so the driver is
        always in a known-good state before each write, even after a long
        sleep period.
        """
        log.info("EPD: waking driver...")
        self.epd.init()
        buf = self.epd.getbuffer(image)
        self.epd.display(buf)
        log.info("EPD: frame written — sleeping driver")
        self.epd.sleep()

    def _blank_canvas(self) -> tuple:
        """Return (image, draw) white canvas."""
        img  = Image.new('1', (EPD_WIDTH, EPD_HEIGHT), 255)
        draw = ImageDraw.Draw(img)
        return img, draw

    # ------------------------------------------------------------------  Reader
    def show_reader_page(self, lines: list, page_num: int,
                         total_pages: int, title: str, bat_pct: int):
        """
        Render a page of text.
        `lines` is a list of strings already word-wrapped.
        """
        margin     = self.config.get('margin_px', 40)
        font_size  = self.config.get('font_size', 28)

        f_body   = _font(FONT_REGULAR, font_size)
        f_small  = _font(FONT_REGULAR, 18)
        f_title  = _font(FONT_BOLD, 20)

        img, draw = self._blank_canvas()

        # ---- header bar ------------------------------------------------
        draw.rectangle([0, 0, EPD_WIDTH, 36], fill=0)
        # Title (truncate if too long)
        short_title = title[:55] + '…' if len(title) > 55 else title
        draw.text((margin, 8), short_title, font=f_title, fill=255)
        # Battery
        _draw_battery(draw, EPD_WIDTH - 80, 8, bat_pct)

        # ---- body text ------------------------------------------------
        y = 50
        line_h = int(font_size * self.config.get('line_spacing', 1.4))
        max_y  = EPD_HEIGHT - 40   # leave room for footer

        for line in lines:
            if y + line_h > max_y:
                break
            draw.text((margin, y), line, font=f_body, fill=0)
            y += line_h

        # ---- footer ---------------------------------------------------
        draw.line([0, EPD_HEIGHT - 32, EPD_WIDTH, EPD_HEIGHT - 32], fill=0, width=1)
        footer = f"Page {page_num + 1} of {total_pages}"
        draw.text((margin, EPD_HEIGHT - 28), footer, font=f_small, fill=0)
        ts = datetime.now().strftime("%H:%M")
        draw.text((EPD_WIDTH - 80, EPD_HEIGHT - 28), ts, font=f_small, fill=0)

        self._display(img)
        log.info("Reader page %d/%d displayed", page_num + 1, total_pages)

    # ------------------------------------------------------------------  Weather
    def show_weather(self, data: dict, bat_pct: int):
        """
        Full-screen weather display.
        `data` dict keys: city, temp, feels_like, humidity, wind_speed,
                          description, forecast (list of dicts), updated_at
        """
        if not data:
            self._show_message("No weather data.\nCheck settings at\nhttp://<pi-ip>:5000")
            return

        f_city    = _font(FONT_BOLD,    42)
        f_temp    = _font(FONT_BOLD,    96)
        f_desc    = _font(FONT_REGULAR, 28)
        f_detail  = _font(FONT_REGULAR, 22)
        f_small   = _font(FONT_REGULAR, 18)
        f_fc_lbl  = _font(FONT_BOLD,    18)

        img, draw = self._blank_canvas()

        # ---- left panel (current) -------------------------------------
        LEFT = 20
        draw.text((LEFT, 10),  data.get('city', 'Unknown'), font=f_city,   fill=0)
        draw.text((LEFT, 62),  data.get('description', '').capitalize(),
                  font=f_desc, fill=0)

        units  = data.get('units', 'imperial')
        t_sym  = '°F' if units == 'imperial' else '°C'
        w_sym  = 'mph' if units == 'imperial' else 'm/s'

        temp_str = f"{data.get('temp', '--'):.0f}{t_sym}"
        draw.text((LEFT, 98), temp_str, font=f_temp, fill=0)

        feels = f"Feels like {data.get('feels_like', '--'):.0f}{t_sym}"
        draw.text((LEFT, 210), feels, font=f_detail, fill=0)

        hum  = f"Humidity:  {data.get('humidity', '--')}%"
        wind = f"Wind:      {data.get('wind_speed', '--'):.1f} {w_sym}"
        draw.text((LEFT, 244), hum,  font=f_detail, fill=0)
        draw.text((LEFT, 272), wind, font=f_detail, fill=0)

        # ---- divider --------------------------------------------------
        draw.line([360, 0, 360, EPD_HEIGHT - 36], fill=0, width=2)

        # ---- right panel (5-day forecast) -----------------------------
        forecast = data.get('forecast', [])[:5]
        col_w    = (EPD_WIDTH - 360) // max(len(forecast), 1)
        for i, day in enumerate(forecast):
            x = 368 + i * col_w
            draw.text((x, 10),  day.get('dow', '?'),              font=f_fc_lbl,  fill=0)
            draw.text((x, 34),  day.get('description', '')[:10],  font=f_small,   fill=0)
            hi  = f"H:{day.get('temp_max','?'):.0f}"
            lo  = f"L:{day.get('temp_min','?'):.0f}"
            draw.text((x, 60),  hi, font=f_detail, fill=0)
            draw.text((x, 86),  lo, font=f_detail, fill=0)

        # ---- footer ---------------------------------------------------
        draw.line([0, EPD_HEIGHT - 36, EPD_WIDTH, EPD_HEIGHT - 36], fill=0, width=1)
        updated = data.get('updated_at', '')
        draw.text((LEFT, EPD_HEIGHT - 30),
                  f"Updated: {updated}", font=f_small, fill=0)
        _draw_battery(draw, EPD_WIDTH - 90, EPD_HEIGHT - 30, bat_pct)

        self._display(img)
        log.info("Weather screen displayed")

    # ------------------------------------------------------------------  Helpers
    def _show_message(self, text: str):
        img, draw = self._blank_canvas()
        f = _font(FONT_REGULAR, 28)
        y = 160
        for line in text.split('\n'):
            draw.text((60, y), line, font=f, fill=0)
            y += 44
        self._display(img)

    def show_boot_screen(self):
        img, draw = self._blank_canvas()
        f_big   = _font(FONT_BOLD,    52)
        f_small = _font(FONT_REGULAR, 24)
        draw.text((180, 170), "DIY E-Reader",   font=f_big,   fill=0)
        draw.text((220, 238), "Starting up…",   font=f_small, fill=0)
        draw.text((160, 290), "Web UI → http://<pi-ip>:5000", font=f_small, fill=0)
        self._display(img)

    def show_library(self, books: list, selected: int, bat_pct: int):
        """Display the library list (up to ~12 entries)."""
        f_title = _font(FONT_BOLD,    22)
        f_item  = _font(FONT_REGULAR, 24)
        f_sel   = _font(FONT_BOLD,    24)
        f_small = _font(FONT_REGULAR, 18)

        img, draw = self._blank_canvas()

        # Header
        draw.rectangle([0, 0, EPD_WIDTH, 36], fill=0)
        draw.text((20, 8), "Library", font=f_title, fill=255)
        _draw_battery(draw, EPD_WIDTH - 80, 8, bat_pct)

        max_visible = 12
        start = max(0, selected - max_visible // 2)
        visible = books[start:start + max_visible]

        y = 46
        for i, book in enumerate(visible):
            actual_i = start + i
            name = os.path.basename(book)
            name = name[:60] + '…' if len(name) > 60 else name
            if actual_i == selected:
                draw.rectangle([10, y - 2, EPD_WIDTH - 10, y + 30], fill=0)
                draw.text((20, y), f"▶ {name}", font=f_sel, fill=255)
            else:
                draw.text((20, y), f"   {name}", font=f_item, fill=0)
            y += 34

        draw.line([0, EPD_HEIGHT - 32, EPD_WIDTH, EPD_HEIGHT - 32], fill=0)
        draw.text((20, EPD_HEIGHT - 26),
                  "BTN1=Up  BTN2=Down  BTN3=Open  BTN4=Back",
                  font=f_small, fill=0)

        self._display(img)


# ------------------------------------------------------------------ Battery icon
def _draw_battery(draw: ImageDraw.ImageDraw, x: int, y: int, pct: int):
    """Draw a small battery icon at (x, y). pct = 0-100."""
    pct = max(0, min(100, pct if pct is not None else 0))
    W, H, nub = 52, 22, 4
    # Outline
    draw.rectangle([x, y, x + W, y + H], outline=0, width=2)
    # Nub
    draw.rectangle([x + W, y + 6, x + W + nub, y + H - 6], fill=0)
    # Fill
    fill_w = int((W - 4) * pct / 100)
    fill_color = 0   # black always on 1-bit display
    if fill_w > 0:
        draw.rectangle([x + 2, y + 2, x + 2 + fill_w, y + H - 2], fill=fill_color)
    # Percentage label
    try:
        f = ImageFont.truetype(FONT_REGULAR, 14)
    except Exception:
        f = ImageFont.load_default()
    draw.text((x + W + nub + 4, y + 4), f"{pct}%", font=f, fill=0)


# ------------------------------------------------------------------ Stub EPD (dev/test)
class _StubEPD:
    """No-hardware stub so the app can run on a dev machine."""
    def init(self):    log.info("[STUB] EPD init")
    def Clear(self):   log.info("[STUB] EPD clear")
    def sleep(self):   log.info("[STUB] EPD sleep")
    def getbuffer(self, img):
        img.save("/tmp/ereader_last_frame.png")
        log.info("[STUB] Frame saved to /tmp/ereader_last_frame.png")
        return b''
    def display(self, buf): log.info("[STUB] EPD display")
