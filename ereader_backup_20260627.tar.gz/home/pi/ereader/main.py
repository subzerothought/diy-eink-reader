#!/usr/bin/env python3
"""
DIY E-Reader - Main Entry Point
Raspberry Pi Zero W + Waveshare 7.5" e-Paper HAT (800x480)
"""

import sys
import os
import threading
import logging
import time

# --- Path setup ---
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'lib'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'waveshare_epd'))

from config import Config
from display_manager import DisplayManager
from book_reader import BookReader
from weather import WeatherManager
from battery import BatteryMonitor
from gpio_handler import GPIOHandler
from web_server import create_app

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(name)s] %(levelname)s: %(message)s',
    handlers=[
        logging.FileHandler('/home/pi/ereader/ereader.log'),
        #logging.StreamHandler()
    ]
)
log = logging.getLogger('main')


def main():
    log.info("=== DIY E-Reader Starting ===")

    # Load config
    config = Config()

    # Core managers
    display = DisplayManager(config)
    battery = BatteryMonitor()
    reader  = BookReader(config)
    weather = WeatherManager(config)

    # Shared app state passed to all modules
    state = {
        'mode': 'weather',          # 'reader' | 'weather'
        'display': display,
        'reader': reader,
        'weather': weather,
        'battery': battery,
        'config': config,
        'lock': threading.Lock(),   # serialise EPD writes
        'last_activity': time.time(),
    }

    # GPIO buttons
    gpio = GPIOHandler(state)
    gpio.start()

    # Flask web server (background thread)
    flask_app = create_app(state)
    web_thread = threading.Thread(
        target=lambda: flask_app.run(host='0.0.0.0', port=5000,
                                     debug=False, use_reloader=False),
        daemon=True,
        name='WebServer'
    )
    web_thread.start()
    log.info("Web interface running on port 5000")

    # Initial screen — clear() handles init+clear+sleep internally
    display.clear()

    # Main loop — switches between reader and weather based on idle timeout
    try:
        while True:
            idle_secs = time.time() - state['last_activity']
            timeout   = config.get('idle_timeout_minutes', 5) * 60

            if state['mode'] == 'reader':
                if idle_secs >= timeout:
                    log.info("Idle timeout — switching to weather")
                    state['mode'] = 'weather'
                    state['weather_drawn'] = False
                    _show_weather(state)
                else:
                    time.sleep(2)

            else:  # weather mode
                refresh = config.get('weather_refresh_minutes', 15) * 60
                was_updated = weather.last_fetch_time()
                weather.maybe_refresh(refresh)
                # Sleep first to allow background fetch thread to complete
                time.sleep(62)
                # Only redraw if data actually changed or first draw
                if weather.last_fetch_time() != was_updated or not state.get('weather_drawn'):
                    _show_weather(state)
                    state['weather_drawn'] = True

    except KeyboardInterrupt:
        log.info("Shutting down...")
    finally:
        gpio.cleanup()
        display.sleep()
        log.info("Goodbye.")


def _show_weather(state):
    """Render weather + battery on the EPD."""
    with state['lock']:
        bat_pct = state['battery'].read_percent()
        state['display'].show_weather(state['weather'].get_data(), bat_pct)


if __name__ == '__main__':
    main()
