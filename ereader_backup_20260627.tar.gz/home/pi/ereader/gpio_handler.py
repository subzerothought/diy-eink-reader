"""
gpio_handler.py — Physical button handling via RPi.GPIO.

Button wiring (all BCM numbers):
  Each button connects the GPIO pin to GND.
  Internal pull-ups are enabled so the pin reads HIGH at rest.

  Button 1 (PREV PAGE / UP)    → GPIO 5  (Pin 29)
  Button 2 (NEXT PAGE / DOWN)  → GPIO 6  (Pin 31)
  Button 3 (SELECT / OPEN)     → GPIO 13 (Pin 33)
  Button 4 (MODE / BACK)       → GPIO 19 (Pin 35)

Pin choice rationale: 5, 6, 13, 19 are grouped together on the lower
GPIO header and are all safe general-purpose inputs on Pi Zero.
They avoid the SPI pins (10/11/8/25) used by the EPD and the I2C
pins (2/3) used by the MAX17043.
"""

import time
import threading
import logging
import os

log = logging.getLogger('gpio')

BTN_PREV   = 5
BTN_NEXT   = 6
BTN_SELECT = 13
BTN_MODE   = 19

DEBOUNCE_MS = 300   # milliseconds


class GPIOHandler:
    def __init__(self, state: dict):
        self.state       = state
        self._gpio_ok    = False
        self._lib_select_idx = 0   # highlight position in library view
        self._mode_held  = False
        self._last_press = {}      # BCM pin → last press time (for debounce)
        self._thread     = None

        try:
            import RPi.GPIO as GPIO
            self.GPIO = GPIO
            GPIO.setmode(GPIO.BCM)
            GPIO.setwarnings(False)
            for pin in (BTN_PREV, BTN_NEXT, BTN_SELECT, BTN_MODE):
                GPIO.setup(pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
            self._gpio_ok = True
            log.info("GPIO initialised OK")
        except (ImportError, RuntimeError) as e:
            log.warning("RPi.GPIO not available (%s) — running headless", e)

    def start(self):
        if not self._gpio_ok:
            return
        self._thread = threading.Thread(target=self._poll_loop,
                                        daemon=True, name='GPIO')
        self._thread.start()
        log.info("GPIO polling started")

    def cleanup(self):
        if self._gpio_ok:
            self.GPIO.cleanup()

    # ------------------------------------------------------------------  Poll loop
    def _poll_loop(self):
        """Simple polling loop with software debounce (no interrupt conflicts with SPI)."""
        while True:
            for pin in (BTN_PREV, BTN_NEXT, BTN_SELECT, BTN_MODE):
                if self.GPIO.input(pin) == self.GPIO.LOW:
                    now = time.time()
                    last = self._last_press.get(pin, 0)
                    if (now - last) * 1000 >= DEBOUNCE_MS:
                        self._last_press[pin] = now
                        self._handle(pin)
                        # Wait for release
                        while self.GPIO.input(pin) == self.GPIO.LOW:
                            time.sleep(0.02)
            time.sleep(0.05)

    # ------------------------------------------------------------------  Dispatch
    def _handle(self, pin: int):
        s = self.state
        mode = s.get('mode', 'weather')
        log.info("Button press: GPIO %d  mode=%s", pin, mode)

        # Update activity timer
        s['last_activity'] = time.time()

        if mode == 'reader':
            self._handle_reader(pin, s)
        elif mode == 'library':
            self._handle_library(pin, s)
        else:
            # Weather mode — any button wakes into reader or library
            if pin == BTN_MODE:
                self._enter_library(s)
            else:
                self._enter_reader(s)

    def _handle_reader(self, pin: int, s: dict):
        reader  = s['reader']
        display = s['display']
        config  = s['config']
        bat     = s['battery'].read_percent()

        if pin == BTN_NEXT:
            if reader.next_page():
                with s['lock']:
                    display.show_reader_page(
                        reader.current_page_lines(),
                        reader.page_index,
                        reader.total_pages,
                        reader.title,
                        bat)
            else:
                log.info("Already at last page")

        elif pin == BTN_PREV:
            if reader.prev_page():
                with s['lock']:
                    display.show_reader_page(
                        reader.current_page_lines(),
                        reader.page_index,
                        reader.total_pages,
                        reader.title,
                        bat)

        elif pin == BTN_SELECT:
            # Toggle bookmark (future feature placeholder)
            log.info("Bookmark toggle (not yet implemented)")

        elif pin == BTN_MODE:
            # Back to library
            self._enter_library(s)

    def _handle_library(self, pin: int, s: dict):
        from book_reader import scan_library
        books   = scan_library(s['config'].get('library_path'))
        display = s['display']
        bat     = s['battery'].read_percent()

        if not books:
            return

        if pin == BTN_PREV:
            self._lib_select_idx = max(0, self._lib_select_idx - 1)
            with s['lock']:
                display.show_library(books, self._lib_select_idx, bat)

        elif pin == BTN_NEXT:
            self._lib_select_idx = min(len(books) - 1, self._lib_select_idx + 1)
            with s['lock']:
                display.show_library(books, self._lib_select_idx, bat)

        elif pin == BTN_SELECT:
            book = books[self._lib_select_idx]
            if s['reader'].load(book):
                s['mode'] = 'reader'
                bat = s['battery'].read_percent()
                with s['lock']:
                    display.show_reader_page(
                        s['reader'].current_page_lines(),
                        s['reader'].page_index,
                        s['reader'].total_pages,
                        s['reader'].title,
                        bat)

        elif pin == BTN_MODE:
            # Exit library without opening a book
            s['mode'] = 'weather'
            s['weather_drawn'] = False

    def _enter_library(self, s: dict):
        from book_reader import scan_library
        books = scan_library(s['config'].get('library_path'))
        s['mode'] = 'library'
        self._lib_select_idx = 0
        bat = s['battery'].read_percent()
        with s['lock']:
            s['display'].show_library(books, 0, bat)

    def _enter_reader(self, s: dict):
        """Wake into reader if a book is loaded, else open library."""
        if s['reader'].is_loaded():
            s['mode'] = 'reader'
            bat = s['battery'].read_percent()
            with s['lock']:
                s['display'].show_reader_page(
                    s['reader'].current_page_lines(),
                    s['reader'].page_index,
                    s['reader'].total_pages,
                    s['reader'].title,
                    bat)
        else:
            self._enter_library(s)
