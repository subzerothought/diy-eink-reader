import RPi.GPIO as GPIO
import spidev
import time

# Pin definitions (BCM)
RST_PIN  = 17
DC_PIN   = 25
CS_PIN   = 8
BUSY_PIN = 24
PWR_PIN  = 18

SPI = spidev.SpiDev()

def module_init():
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)
    # Only setup EPD pins — button pins are owned by gpio_handler.py
    for pin, direction in [(RST_PIN, GPIO.OUT),(DC_PIN, GPIO.OUT),(PWR_PIN, GPIO.OUT),(BUSY_PIN, GPIO.IN)]:
        try:
            GPIO.setup(pin, direction)
        except Exception:
            pass
    GPIO.output(PWR_PIN, GPIO.HIGH)
    try:
        SPI.open(0, 0)
        SPI.max_speed_hz = 4000000
        SPI.mode = 0b00
    except Exception:
        pass
    return 0

def module_exit():
    SPI.close()
    GPIO.output(RST_PIN, GPIO.LOW)
    GPIO.output(DC_PIN,  GPIO.LOW)
    GPIO.output(PWR_PIN, GPIO.LOW)
    # Do not call GPIO.cleanup() here — gpio_handler.py owns GPIO lifetime

def digital_write(pin, value):
    if pin == CS_PIN:
        return
    GPIO.output(pin, value)

def digital_read(pin):
    return GPIO.input(pin)

def delay_ms(ms):
    time.sleep(ms / 1000.0)

def spi_writebyte(data):
    SPI.writebytes(data)

def spi_writebyte2(data):
    SPI.writebytes2(data)
