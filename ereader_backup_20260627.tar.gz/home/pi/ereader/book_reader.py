"""
book_reader.py — Parse .txt and .pdf files into display-ready pages.

Page layout is computed at load time so navigation is instant.
"""

import os
import textwrap
import logging
from PIL import ImageFont

log = logging.getLogger('reader')

FONT_DIR     = "/usr/share/fonts/truetype/dejavu"
FONT_REGULAR = os.path.join(FONT_DIR, "DejaVuSans.ttf")

EPD_WIDTH  = 800
EPD_HEIGHT = 480


def _font(size):
    try:
        return ImageFont.truetype(FONT_REGULAR, size)
    except Exception:
        return ImageFont.load_default()


class BookReader:
    def __init__(self, config):
        self.config     = config
        self.title      = ""
        self.pages      = []          # list of list-of-strings (lines per page)
        self.page_index = 0
        self.file_path  = ""

    # ------------------------------------------------------------------  Public API
    def load(self, path: str) -> bool:
        """Load a file. Returns True on success."""
        ext = os.path.splitext(path)[1].lower()
        try:
            if ext == '.txt':
                raw = self._read_txt(path)
            elif ext == '.pdf':
                raw = self._read_pdf(path)
            else:
                log.error("Unsupported format: %s", ext)
                return False

            self.title     = os.path.splitext(os.path.basename(path))[0]
            self.file_path = path
            self.pages     = self._paginate(raw)
            self.page_index = 0

            # Restore last position if same book
            if self.config.get('last_book') == path:
                saved = self.config.get('last_page', 0)
                self.page_index = min(saved, len(self.pages) - 1)

            self.config.set('last_book', path)
            self.config.set('last_page', self.page_index)
            log.info("Loaded '%s'  (%d pages)", self.title, len(self.pages))
            return True

        except Exception as e:
            log.exception("Failed to load %s: %s", path, e)
            return False

    def current_page_lines(self) -> list:
        if not self.pages:
            return ["No book loaded."]
        return self.pages[self.page_index]

    def next_page(self) -> bool:
        if self.page_index < len(self.pages) - 1:
            self.page_index += 1
            self._save_position()
            return True
        return False

    def prev_page(self) -> bool:
        if self.page_index > 0:
            self.page_index -= 1
            self._save_position()
            return True
        return False

    def goto_page(self, n: int):
        self.page_index = max(0, min(n, len(self.pages) - 1))
        self._save_position()

    @property
    def total_pages(self) -> int:
        return len(self.pages)

    def is_loaded(self) -> bool:
        return bool(self.pages)

    # ------------------------------------------------------------------  File readers
    @staticmethod
    def _read_txt(path: str) -> str:
        """Read a UTF-8 / Latin-1 text file."""
        for enc in ('utf-8', 'utf-8-sig', 'latin-1'):
            try:
                with open(path, encoding=enc) as f:
                    return f.read()
            except UnicodeDecodeError:
                continue
        raise ValueError(f"Cannot decode {path}")

    @staticmethod
    def _read_pdf(path: str) -> str:
        """Extract all text from a PDF using pdfminer.six."""
        try:
            from pdfminer.high_level import extract_text
            text = extract_text(path)
            if not text or not text.strip():
                log.warning("PDF appears to be image-only: %s", path)
                return "[This PDF contains no selectable text (scanned image).]"
            return text
        except ImportError:
            log.error("pdfminer.six not installed")
            return "[PDF support requires: pip install pdfminer.six]"

    # ------------------------------------------------------------------  Paginator
    def _paginate(self, raw: str) -> list:
        """
        Break raw text into pages.
        Each page is a list of display-ready strings.
        """
        font_size   = self.config.get('font_size',    28)
        line_spacing = self.config.get('line_spacing', 1.4)
        margin      = self.config.get('margin_px',    40)

        font   = _font(font_size)
        line_h = int(font_size * line_spacing)

        # Usable area
        text_w  = EPD_WIDTH  - margin * 2
        # Header = 50px, footer = 40px
        text_h  = EPD_HEIGHT - 50 - 40
        lines_per_page = max(1, text_h // line_h)

        # Compute wrap width in characters by measuring average glyph width
        try:
            sample = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
            bbox   = font.getbbox(sample)
            avg_w  = (bbox[2] - bbox[0]) / len(sample)
            wrap_w = max(10, int(text_w / avg_w))
        except Exception:
            wrap_w = 40

        # Split raw text into paragraphs, wrap each
        all_lines = []
        paragraphs = raw.split('\n')
        for para in paragraphs:
            para = para.rstrip()
            if para == '':
                all_lines.append('')   # blank separator
            else:
                wrapped = textwrap.wrap(para, width=wrap_w)
                all_lines.extend(wrapped if wrapped else [''])

        # Chunk into pages
        pages = []
        for i in range(0, len(all_lines), lines_per_page):
            pages.append(all_lines[i:i + lines_per_page])

        return pages if pages else [['']]

    # ------------------------------------------------------------------  Helpers
    def _save_position(self):
        self.config.set('last_page', self.page_index)


# ------------------------------------------------------------------  Library scanner
def scan_library(library_path: str) -> list:
    """Return sorted list of .txt and .pdf files under library_path."""
    if not os.path.isdir(library_path):
        os.makedirs(library_path, exist_ok=True)
        return []
    results = []
    for root, _, files in os.walk(library_path):
        for f in files:
            if f.lower().endswith(('.txt', '.pdf')):
                results.append(os.path.join(root, f))
    return sorted(results)
